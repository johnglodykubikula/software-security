package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ChecksumController {

    @RequestMapping("/hash")
    public String getChecksum() {
      
        String uniqueData = "Artemis Financial Data Security Check - john glody kubikula";
        
        try {

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(uniqueData.getBytes(StandardCharsets.UTF_8));
            
        
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            String checksum = hexString.toString();
            
         
            return "<html><body style='font-family: Arial, sans-serif; margin: 40px;'>" +
                   "<h2>Report for  Artemis Financial</h2>" +
                   "<p><strong>data :</strong> " + uniqueData + "</p>" +
                   "<p><strong>checksum SHA-256 :</strong> <span style='color: green; font-family: monospace;'>" + checksum + "</span></p>" +
                   "</body></html>";
                   
        } catch (NoSuchAlgorithmException e) {
            return "error : cannot find algorithm";
        }
    }
}